alias wee="git"
