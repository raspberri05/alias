# gcm "commit_message"
# git commit -m "commit_message"
alias gcm="git commit -m"
